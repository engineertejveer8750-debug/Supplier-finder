const SUPPLIERS = [
  {
    "name": "Global Electrical Company",
    "location": "Mohali, Punjab",
    "phone": "+91 98142 12874",
    "email": "gecindian@gmail.com",
    "products": "Breakers & switches; Control products; Enclosures & DIN rail",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Hanuman Electricals",
    "location": "Industrial Area Phase-2, Chandigarh",
    "phone": "+91 97800 49012",
    "email": "mgoyal22@gmail.com",
    "products": "Enclosures; DIN rail; Wiring accessories",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Jagan Gopala & Co.",
    "location": "Sector 26, Chandigarh",
    "phone": "+91 98140 42134",
    "email": "jagangopala@yahoo.co.in",
    "products": "Breakers; Control; Enclosures; CSS; Distribution automation",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Shree Balaji Electric Co.",
    "location": "Industrial Area Phase-2, Chandigarh",
    "phone": "+91 98726 35919",
    "email": "balaji405a@gmail.com",
    "products": "Breakers; Enclosures; Wiring accessories",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "EMCO Switchgears Pvt. Ltd.",
    "location": "Industrial Area Phase-1, Chandigarh",
    "phone": "+91 98726 17674",
    "email": "gsm@emcoswitchgears.com",
    "products": "LV products; Main distribution boards / panel building",
    "source": "ABB official partner record"
  },
  {
    "name": "Akshar Sales Corporation",
    "location": "New Vadaj, Ahmedabad",
    "phone": "+91 93274 18080",
    "email": "aksharsales@hotmail.com",
    "products": "Breakers; Switches; Control; Wiring; Enclosures",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Bimal Corporation",
    "location": "Ahmedabad",
    "phone": "+91 93270 18624",
    "email": "bimalcorpo@gmail.com",
    "products": "Enclosures; Wiring accessories",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Comet Electricals",
    "location": "Titanium City Centre, Satellite, Ahmedabad",
    "phone": "+91 92272 28848",
    "email": "cometelectricals@gmail.com",
    "products": "Breakers; Switches; Control; Enclosures",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "DJ Associates",
    "location": "Near Gujarat College Railway Crossing, Ahmedabad",
    "phone": "+91 97129 46766",
    "email": "djassociates.2011@gmail.com",
    "products": "Breakers; Switches; Control; Enclosures",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Durga Mechatronics Pvt. Ltd.",
    "location": "Thaltej, Ahmedabad",
    "phone": "+91 81415 55697",
    "email": "yash.sultania@durgamechatronics.com",
    "products": "Breakers; Switches; Control; Enclosures",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Hiecon Technologies",
    "location": "Satellite Road, Ahmedabad",
    "phone": "+91 98240 14949",
    "email": "trupti@hiecon.com",
    "products": "Breakers; Control; Enclosures; Wiring",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Powermach Switchgears",
    "location": "Kathwada, Ahmedabad",
    "phone": "+91 93270 00100",
    "email": "powermach.dilip@gmail.com",
    "products": "Breakers; Control; Enclosures",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Pacard Power Pvt. Ltd.",
    "location": "Satellite, Ahmedabad",
    "phone": "+91 98250 68394",
    "email": "pacardpower2000@gmail.com",
    "products": "UPS products",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Radiant Technologies",
    "location": "Iscon-Ambli Road, Ahmedabad",
    "phone": "+91 98983 38953",
    "email": "radiant.care@gmail.com",
    "products": "Breakers; Switches; Control; Enclosures",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Rushil Enterprise / Trade-Well",
    "location": "Ahmedabad",
    "phone": "+91 98251 91720",
    "email": "info@tradewell.co.in",
    "products": "Breakers; Control; Enclosures; Wiring; Distribution automation",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Shefali Enterprise",
    "location": "Ambawadi, Ahmedabad",
    "phone": "+91 98240 08800",
    "email": "shefalienterprise@rediffmail.com",
    "products": "Breakers; Control; Enclosures; Wiring",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Unitech Marketing Corporation",
    "location": "Nehrunagar, Ahmedabad",
    "phone": "+91 94260 20163",
    "email": "tambe987@yahoo.co.in",
    "products": "Breakers; Control; Enclosures",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Vashi Integrated Solutions Ltd.",
    "location": "Pirana, Ahmedabad",
    "phone": "+91 75067 19951",
    "email": "amit.bhavsar@vashiisl.com",
    "products": "Breakers; Control; Enclosures; Installation",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "VD Electrical & Engineering Co.",
    "location": "Narol, Ahmedabad",
    "phone": "+91 94273 02722",
    "email": "mayur@vdelectricals.com",
    "products": "Breakers; Control; Enclosures",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Vidhyut Technical Service",
    "location": "Gurukul Road, Ahmedabad",
    "phone": "+91 99090 04032",
    "email": "darshan@vidhyuttech.com",
    "products": "Breakers; Control; Enclosures",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Vinworth Eletech Pvt. Ltd.",
    "location": "Changodar/Sanand, Ahmedabad",
    "phone": "+91 82009 20878",
    "email": "sales@vinworth.in",
    "products": "Breakers; Control; Enclosures",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Vipul Traders",
    "location": "Paldi, Ahmedabad",
    "phone": "+91 94288 25854",
    "email": "vrtraders1983@gmail.com",
    "products": "Breakers; Control; Enclosures",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Arihant Electricals",
    "location": "Okhla Industrial Area, New Delhi",
    "phone": "+91 99106 98009",
    "email": "amit.jain@arihantelectricals.com",
    "products": "Breakers; Control products; Enclosures",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "AVS Engineers & Traders",
    "location": "Patparganj, Delhi",
    "phone": "+91 98107 00164",
    "email": "avsengineers02@gmail.com",
    "products": "Breakers; Control; Enclosures; Wiring",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "ES Electrical Switchgears & Controls",
    "location": "DSIIDC Scheme I, Delhi",
    "phone": "+91 98114 86863",
    "email": "puneet@esccables.in",
    "products": "Breakers; Control; Enclosures",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "GKM Power Projects",
    "location": "G.B. Road, Delhi",
    "phone": "+91 98110 80335",
    "email": "commercial@gkmpower.com",
    "products": "MV products; RMU; Substations",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Industrial Control Systems",
    "location": "Bhagirath Palace, Delhi",
    "phone": "+91 98102 93834",
    "email": "ics_53@hotmail.com",
    "products": "MV; Distribution automation",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Kaydee Engineers",
    "location": "Rajendra Place, Delhi",
    "phone": "+91 98112 25530",
    "email": "kaydee.engineers@yahoo.in",
    "products": "MV/LV breakers; Relays; RMU; SCADA",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Maheshwari Industrial Syndicate",
    "location": "Bhagirath Palace, Delhi",
    "phone": "+91 98111 56895",
    "email": "misdelhi.dp@gmail.com",
    "products": "Breakers; Control; Enclosures",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Pankaj Electricals",
    "location": "Noida",
    "phone": "+91 98910 93600",
    "email": "p.methi@pankaj.biz",
    "products": "Breakers; Control; Enclosures; Wiring",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "SM Electrical Enterprises",
    "location": "Sector 9, Noida",
    "phone": "+91 95405 84348",
    "email": "smee64@gmail.com",
    "products": "Breakers; Control; Enclosures",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "SN Electel Pvt. Ltd.",
    "location": "Sahibabad Industrial Area, Ghaziabad",
    "phone": "+91 93139 14000",
    "email": "snelectel@gmail.com",
    "products": "Enclosures; Wiring accessories",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Shree Anant Electric Stores",
    "location": "Bhagirath Palace, Delhi",
    "phone": "+91 98100 09060",
    "email": "shreeanant1@gmail.com",
    "products": "Breakers; Control; Enclosures; Wiring",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "System Control & Switchgears",
    "location": "Naraina Industrial Area, Delhi",
    "phone": "+91 93122 21517",
    "email": "system.controls@gmail.com",
    "products": "Breakers; Control; Enclosures; Wiring",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Concept Power System Pvt. Ltd.",
    "location": "Janakpuri, Delhi",
    "phone": "+91 98180 67555",
    "email": "conceptpowersystem@gmail.com",
    "products": "CSS; MV outdoor; RMU",
    "source": "ABB official channel-partner directory"
  },
  {
    "name": "Prithvi Electric",
    "location": "Daultabad Road, Gurugram",
    "phone": "—",
    "email": "—",
    "products": "ABB MCB and electrical products",
    "source": "Delhi-NCR dealer listing; verify current authorization"
  },
  {
    "name": "Denvy Automation",
    "location": "New Delhi",
    "phone": "—",
    "email": "—",
    "products": "ABB switchgear; Automation",
    "source": "Delhi-NCR dealer listing; verify current authorization"
  }
];