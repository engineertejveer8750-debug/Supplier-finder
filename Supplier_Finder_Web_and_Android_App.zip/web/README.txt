# Supplier Finder — Starter Website

Open `index.html` in a browser. No server or installation is required.

Included:
- Search by supplier, product, brand/make text, location, email or phone
- Location filter
- Product-category filter
- Responsive mobile/desktop layout
- Click-to-call and click-to-email
- Current starter supplier data in `data.js`

To add suppliers, edit `data.js` and add records using the same fields:
name, location, phone, email, products, source.

Important: supplier authorization, availability and contact details should be verified before procurement.
