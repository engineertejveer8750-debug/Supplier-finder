SUPPLIER FINDER — WEB/PWA + ANDROID

WEB/PWA: Upload the contents of the web folder to a static HTTPS host. Open the URL in Chrome and choose Install/Add to Home screen.

ANDROID: Open the android folder in Android Studio, let Gradle sync, then Build > Build APK(s). The APK appears in app/build/outputs/apk/debug/.

The same supplier database is included in both versions. Current data is the ABB supplier directory previously compiled; verify authorization/contact details before procurement use.
